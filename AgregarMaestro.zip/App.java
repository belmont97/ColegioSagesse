package SW.E6.ColegioSagesse;
import static spark.Spark.*;

import com.mysql.cj.xdevapi.JsonArray;
import com.mysql.cj.xdevapi.JsonParser;

import org.json.JSONObject;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        options("/*", (request, response) -> {
            String accessControlRequestHeaders = request.headers("Access-Control-Request-Headers");
            if (accessControlRequestHeaders != null) {
                response.header("Access-Control-Allow-Headers", accessControlRequestHeaders);
            }
            String accessControlRequestMethod = request.headers("Access-Control-Request-Method");
            if (accessControlRequestMethod != null) {
                response.header("Access-Control-Allow-Methods", accessControlRequestMethod);
            }
            return "OK";
        });
        before((request, response) -> response.header("Access-Control-Allow-Origin", "*"));
        before((req, res)->res.type("application/json"));
        post("/tablaMaestros", (req, res)->{
            String msj = "Hello World!";
            return msj;
        });

        post("/guardarMaestro", (req, res)->{
            Boolean validaGuardar;
            JSONObject maestroJsonObject = new JSONObject(req.body());
            Maestro maestro = new Maestro();
            maestro.setNumeroDeTrabajador(maestroJsonObject.getString("NumeroDeTrabajador"));
            maestro.setNombre(maestroJsonObject.getString("Nombre"));
            maestro.setRfc(maestroJsonObject.getString("Rfc"));
            maestro.setCurp(maestroJsonObject.getString("Curp"));
            maestro.setDireccion(maestroJsonObject.getString("Direccion"));
            maestro.setEdad(maestroJsonObject.getString("Edad"));
            maestro.setNumeroCelular(maestroJsonObject.getString("NumeroTelefono"));
            maestro.setCorreoInst(maestroJsonObject.getString("CorreoInstitucional"));
            validaGuardar = Maestro.guardarMaestro(maestro);
            
            return validaGuardar;
            
        });
    }
}
